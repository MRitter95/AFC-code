% returns (in bytes) the size of a file in the current working directory
%useage dasize = filesize(filename)
%updated Feb 26 2016

function dasize = f_filesize(filename)
    filestats = dir(sprintf('%s/%s',pwd,filename));
    
    dasize = filestats.bytes;   

end