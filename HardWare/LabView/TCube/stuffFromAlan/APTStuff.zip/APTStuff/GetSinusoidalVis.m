% useage: [Vis, errVis,PeakCounts,LSval] = GetSinusoidalVis(xdata, ydata, figaxhandle)
%
%xdata (ydata) - row or col vector of the independent (dependent) data, 
%
%put a trace of the fit on the figure too
%

function [Vis, errVis,PeakCounts,LSval] = GetSinusoidalVis(xdata, ydata, figaxhandle)%#ok
    
    deg2rad = @(deg) deg*pi/180;
    dafunc = @(params,x) params(1)*cos(4*(deg2rad(x)-params(2)))+params(3);
    
    
    
    [ymax, maxind]= max(ydata); %#ok
    [ymin]= min(ydata);
    
    paramsTrial(1) = (ymax-ymin)/2;
    paramsTrial(2) = xdata(maxind);
    paramsTrial(3) = (ymax+ymin)/2;

    
    errfunc  = @(params) sum(((dafunc(params,xdata)-ydata).^2)./(ydata+1));
    
    paramsOpt = fminsearch(@(params) errfunc(params), paramsTrial, optimset('MaxFunEvals', 2e9));
    
    PeakCounts = paramsOpt(1)+paramsOpt(3);
    
    LSval     = errfunc(paramsOpt);

    
    costfunc = @(params) errfunc(params)*(length(ydata(:))-length(paramsOpt))/errfunc(paramsOpt);
    deltacost = 1; %if cost func goes up/down by this much, how do the params change?
    deltaparams = errorfunc(  @(params) costfunc(params), paramsOpt', deltacost ); 
    
    Vis = paramsOpt(1)/paramsOpt(3);
    
    errVis = Vis*sqrt( (deltaparams(1)/paramsOpt(1))^2 + (deltaparams(3)/paramsOpt(3))^2 );
    
    
    xth = linspace(min(xdata),max(xdata), 1000);
    yth = dafunc(paramsOpt, xth);
    hold(figaxhandle, 'on');
        plot(figaxhandle, xth, yth,'r');
    hold(figaxhandle, 'off');
end