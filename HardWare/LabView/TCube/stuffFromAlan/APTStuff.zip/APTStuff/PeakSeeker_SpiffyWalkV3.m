%PeakSeekerSpeedy_Spiffy.m updated Feb 10 2016
%dependencies:
%
%InitializeAxis.m %% for initializing Piezo controllers
% f_MoveHWP.m  %% for moving HWP rotation mounts...
%RunOrtec.m %% taking control of the Ortec Card
%GetGaussianPeak.m (which in turn depends on)
% errorfunc.m


%is there a way we can speed things up? 
clearvars -except dapol Zeroed defaultvalues    HWPguifig HWPaxes   PiezoGUIfigs theArms tweakfig ; 


Logfilename = sprintf('LogOfMoves.%s.txt', datestr(now,'YYYY-mm-dd'));
SuperLogfilename = sprintf('SuperLog.%s.txt', datestr(now,'YYYY-mm-dd'));
Logfile = fopen(Logfilename, 'at');
SuperLog = fopen(SuperLogfilename, 'at');
fprintf(Logfile,  '%% This file can be read as a Cell array in MATLAB.  %s hrs\r\n', datestr(now,'YYYY-mm-DD HH.MM.SS'));
fprintf(Logfile, '%% Prints these guys out: \r\n');
fprintf(Logfile, '%% starttime (string), \t knob counters, distance between coincidence beams,  distance between H-H coincidence singles beams,   dist between VV coincidence-singles beams,          Hbestvals,                  Vbestvals,                  Hbestvals_sing,             Vbestvals_sing,   peakcoincs(H) and (V)\r\n');
%SuperLog:
fprintf(SuperLog, '%% This super log file can be read as a Cell array in MATLAB.  %s hrs\r\n', datestr(now,'YYYY-mm-DD HH.MM.SS'));
fprintf(SuperLog, '%% Description of each column:\n');
fprintf(SuperLog, '%% time (str),\t Pump Pol (H or V, string), \t knob counters, \t fiber-tip positions [ArmA-x,z, ArmB-x,z], \t FPGA gatewidth, \t [Ortec Starts, Ortec Estimated Stops, Coincidence ROI, Afterpulse ROI, Small Background ROI, Big Background ROI]\n');
5
% fclose(Logfile);
%Log file for recording all the knob turns... 
peakcoinc = [NaN NaN];

%delete all figures except... HWPguifig and PiezoGUIfigs
all_figs = findall(0, 'type', 'figure');
figstoexclude = []; %figures that we DON'T want closed... 
if (exist('HWPguifig','var') && exist('HWPaxes','var') && exist('PiezoGUIfigs','var') && exist('theArms','var')) % both the GUI windows for waveplates and 
%     setdiff(all_figs, [HWPguifig, PiezoGUIfigs])
    if ~exist('tweakfig') tweakfig =[]; end
    delete(setdiff(all_figs, [HWPguifig, PiezoGUIfigs, tweakfig])); % delete everything except the gui interfaces for the various axes
else
    clear HWPguifig HWPaxes   PiezoGUIfigs theArms ;
    close all;
end


format short 
starttimestr = sprintf('start time: %s', datestr(now, 'HH.MM.SS'));
fprintf(1, 'start time: %s\n', datestr(now, 'HH.MM.SS'));


%start the Ortec Card interface:
e=actxserver('LabVIEW.Application');
vipath='C:\Users\pdclab\Desktop\UBER program from Ware modified for FPGA\Coincidence VI, New\Take Data AM2.vi';
vi=invoke(e,'GetVIReference',vipath);


tmpdata = vi.GetControlValue('Settings');
FPGA_Gatewidth = tmpdata{4};



% [year month day hour minute seconds]
clock2sec = @(clock) clock(end) + 60*clock(end-1) + 3600*clock(end-2) + 24*3600*clock(end-3);



%initialize the APT controller HWPs

HWPnames = {'Pump', 'ArmA', 'ArmB'};
anglesettings = [[275, 308, 186]; ...
                [320, 354, 232]];
serialnumbers = [83840800, 83825657, 83835882];




fpos = get(0, 'DefaultFigurePosition');
if (~exist('HWPguifig','var') || ~exist('HWPaxes','var')) % don't need to re-initialize  all the axes...
    HWPguifig = figure('Position', fpos,'name', 'HWP + Piezo controllers');
        set(gcf, 'closer', '');
    for k = 1: 3%%length(HWPaxes)
        HWPaxes(k) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20 (3-k)*200 320 180]); 
        %
        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [150 [(4-k)*200-50] 50 20] );
        set(mTextBox,'String',HWPnames{k});
        
        %
        HWPaxes(k).StartCtrl;
        set(HWPaxes(k),'HWSerialNum', serialnumbers(k));
    %     HWPaxes(k).Identify;
        pause(5);
%         HWPaxes(k).DisableHWChannel(0);
        pause(1);
        HWPaxes(k).EnableHWChannel(0);
%         set(gcf, 'closer', '');
    end
    drawnow();
        
    pause (5); % wait for GUI shit to load    
else %otherwise just start the GUI again
    for k = 1:length(HWPaxes)
        HWPaxes(k).StartCtrl;
    end    
end


%zero
if (~exist('Zeroed'))
    Zeroed = 0;
end


if (~Zeroed)
    parfor k = 1:3%:length(HWPaxes)
        HWPaxes(k).MoveHome(0,0);              
    end
    
    coords = zeros(1,3);
    tic
    while(1)
        for k = 1:3
            coords(k) = HWPaxes(k).GetPosition_Position(0);
        end
        if (norm(coords)<0.002)
            break;
        end        
        datime = toc; 
        if (datime>60)
            break;
        end
    end        
    Zeroed = 1;
end




nreads = 1;  % 1 data point, 2 second integration time/data point




if ~exist('defaultvalues')
    defaultvalues = [ ...
                       [10.00 10.00 13.16 8.53] 
                       [10.00 10.00 12.46 7.29] 
                    ];
else
    defaultvalues
end



%activate the piezo axes... 




ArmsNames = {'ArmA-x';      'ArmA-z';    'ArmB-X'; 'ArmB-Z'};
PiezoSerials = [91858837,   91858839,   91814391, 91814393];


if (~exist('PiezoGUIfigs') || ~exist('theArms'))  %PiezoGUIfigs theArms
    theArms = [];
    PiezoGUIfigs = HWPguifig; %figure('name','Piezo Controllers');
    for k = 1:length(ArmsNames)
        figplacement = [350 ((length(ArmsNames)-k)*200) 250 180];
        tmp = InitializeAxis(PiezoSerials(k), PiezoGUIfigs, defaultvalues(1,k), figplacement);
        theArms = [theArms,tmp];

        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [figplacement(1)+100, ((length(ArmsNames)-k+1)*200-40) 50 20] );
        set(mTextBox,'String',ArmsNames{k});         
    end
else %otherwise, just restart the GUI
    for k = 1:length(theArms)
        theArms(k).StartCtrl;
        theArms(k).SetIPSource(0,5); % allow only POT and software input
        theArms(k).SetVoltPosDispMode(0,2); % 2 for microns
        theArms(k).SetControlMode(0,4);%3 for open-loop, 4 for closed loop
    end    
end






% depth3 = {'Right-Hand Rotate 1/10 rotation'; ' Left-Hand Rotate 1/10 rotation'};
polchangemessage = {'Polarization Change: Go to H-V-H'; 'Polarization Change: Go to V-H-V'};
polmessage =        {'H-pol pump results: '           ; 'V-pol pump results: '};



Hbestvals = [];
Vbestvals = [];



       
knobnames = {'M1B', 'M1C', 'M1T', 'M2B', 'M2C', 'M2T'};
%DONT play with the PBS knobs... (very dangerous) 
%they are finnicky, and it is difficult to gauge how far one has moved


%M1B = Horizontal knob..    %M1C = inner knob (such that all 3 knobs in
%tandem will change z direction of mirror)
knobcntr = eval( input('Give current values of knob counters', 's') );
% knobcntr =[0,   0,      0,      0,      0,      0]; %counts the number of turns of each knob, in 1/10 of a revolution
%
tweaknob = [];
scanknob = [];

if (~exist('tweakfig'))
    tweakfig = []; tweakfigax = []; % handles for the various figures created for each tweak... 
end



while(1) %start, which knob to tweak?
    
    tweaknob = [];    
    while(isempty(tweaknob))
        tmpstr = upper(input('Give new tweak knob:', 's'));
        tmpstr = upper(tmpstr);
        for k  = 1:length(knobnames)
            if strcmp(tmpstr,knobnames{k})
                tweaknob = k;
                break;
            end
        end            
    end 
    if (tweaknob <=6)
        scanknob = tweaknob + 3; % complementary knobs are separated by 3 spaces in the array
        if (scanknob > 6)
            scanknob = scanknob - 6;
        end
    else %tweaknob>6
        scanknob = tweaknob; %these guys don't have complimentary knobs
    end
    
    tweakknobchange = [];
    
    tweakknobchange = str2num( input(sprintf('By how much has knob %s changed (+/-) (right/left hand rotation)? ',knobnames{tweaknob}), 's'));

    knobcntr(tweaknob) =  knobcntr(tweaknob) + tweakknobchange;
    tweakfig(end+1) = figure('name', sprintf('Tweak %s = %2.2f x 0.1 turns', knobnames{tweaknob},knobcntr(tweaknob)));        
    set(gcf, 'closer', '');
%     tweakfigax(end+1) = gca;
    for m = 1:3
        for n = 1:5
            subplot(3,5,(m-1)*5+(n-1) + 1);
            tweakfigaxes(m,n) = gca;
        end
    end

    
    continuescanning = true;
    
    scanknobvalues = [];
    scanknob_beamdist_values = [];
    scanknobchange = [];
    while (continuescanning)  % start, scan the scanknob
        
        for k = 1:length(theArms)
            theArms(k).StartCtrl;
        end
        for k = 1:length(HWPaxes)
            HWPaxes(k).StartCtrl;
        end
        
        if isempty(scanknobchange) %new scan
            scanknobchange = 0; %use this to get a baseline value... 
        else % ask user how scanknob has changed... by how many tenths of a revolution has it changed?
            scanknobchange = 0;
            while (norm(scanknobchange)<=0.0001)
                scanknobchange = str2num( input(sprintf('By how much has knob %s changed (+/-) for (right/left hand rotation)? ',knobnames{scanknob}), 's'));
                if (isempty(scanknobchange))
                    scanknobchange = 0;
                else
                    if isnan(scanknobchange)
                        continuescanning = false; 
                        break;
                    else%finally, we're changing a value
                        knobcntr(scanknob) =  knobcntr(scanknob) + scanknobchange;                        
                    end
                end
            end           
        end
        scanknobvalues = [scanknobvalues, knobcntr(scanknob)];
        
        
        if (~continuescanning) % stop scanning... 
            %save the tweakfigure
            fig_filename = sprintf('fig_Ending%s_Tweak_%s=%2.2f.fig',starttimestr,knobnames{tweaknob},knobcntr(tweaknob));
            saveas(tweakfig(end), fig_filename, 'fig')
            fprintf(Logfile, '%% Saved a figure to: %s\n',fig_filename)
            fprintf(SuperLog, '%% Saved a figure to: %s\n',fig_filename)
            break;
        end

        first_polarization = 1;
        starttimestr = (datestr(now, 'HH.MM.SS'))
        while(1) % look at the 2 different beams... 
            currenthwps = [HWPaxes(1).GetPosition_Position(0), HWPaxes(2).GetPosition_Position(0), HWPaxes(3).GetPosition_Position(0)];
            if (first_polarization)
                if norm(currenthwps-anglesettings(1,:))<=0.01
                    dapol = 1; % H-pump
                else
                    dapol = 2; % V-pump
                end
            else
                 dapol = 3-dapol;
        %          input(polchangemessage{dapol}, 's');
            end

            figure('name', sprintf('%s: Tweaked %s = %2.2f, Scanning %s at %2.2f',polmessage{dapol}, knobnames{tweaknob},knobcntr(tweaknob), knobnames{scanknob},knobcntr(scanknob))); 
            for k = 1:4
                subplot(2,2,k);
                CoincScanAxes(k) = gca;
            end    

            whichPols = dapol; % 1 for H-pump beam, 2 for V-pump beam

            %which set of polarizations to change to?
            f_MoveHWP(HWPaxes , anglesettings(whichPols,:));  % move all 3 rotation mounts at once

            bestvals = [];
            bestvals_sing = [];
            
            %initialize each of the 4 arms so that they are at the
            %'defaultvalues':
            for cnt = 1:length(theArms) 
                currentArm = theArms(cnt);
                f_MovePiezo(currentArm, defaultvalues(dapol,cnt));       
            end
            
            for cnt = 1:length(theArms) % switch between the different Axes of the Piezo actuators

                currentArm = theArms(cnt);
        %         [tmp, x0] = currentArm.GetPosOutput(0,0);
                x0 = defaultvalues(dapol,cnt);

                xvals = x0+linspace(-1,1,3);

                if (max(xvals)>20)
                    xvals = xvals - (max(xvals)-20);
                end

                coincval = [];
                title(CoincScanAxes(cnt),ArmsNames{cnt}); 
                currentArm.SetPosOutput(0, min(xvals));


                if (cnt<=2) % Look at ArmA singles as well... 
                    singlesStr = 'Ortec Starts';
                else  %Look at ArmB singles...
                    singlesStr = 'Ortec Estimated Stops';
                end

                for xval = xvals

                    f_MovePiezo(currentArm, xval);       
                    RestOfTheDataString = {'Ortec Starts', 'Ortec Estimated Stops', 'Coincidence ROI', 'Afterpulse ROI', 'Small Background ROI', 'Big Background ROI'};
                    tmpData = RunOrtec(vi, nreads, {singlesStr, 'Coincidence ROI',RestOfTheDataString{:}});
                    coincval = [coincval; tmpData(1:2)];
                    plot(CoincScanAxes(cnt),xvals(1:length(coincval))', [0.1*coincval(:,1)], '-v', ...
                               xvals(1:length(coincval))',  coincval(:,2) ,     '-o');
                    h = legend(CoincScanAxes(cnt),'singles/10', 'coincs');
                    title(CoincScanAxes(cnt),ArmsNames{cnt}); 
                    set(h, 'location', 'best');
                    
                    
                    %Get Positions of theArms:
                    armvals = [(1:4)*NaN];
                    for m = 1:length(theArms)
                        [tmp, armvals(m)] = theArms(m).GetPosOutput(0,0);
                    end
                    
                    fprintf(SuperLog, ' ''%s'' \t ''%s'' \t [%2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f] \t [%2.2f, %2.2f, %2.2f, %2.2f] \t %i \t [%i, %i, %i, %i, %i, %i] \n', ...
                                starttimestr, polmessage{1}(1), knobcntr,                                 armvals,           FPGA_Gatewidth,   tmpData(3:end)                     );
                    
                    drawnow();
                end

                % we have 3 points... let's fit it to a Gaussian...  
                [xpeakguess errval]           = GetGaussianPeak(xvals, coincval(:,2)');
                if (xpeakguess<(min(xvals)+0.5))
                    xvalsnew = [(min(xvals)-3):1:(min(xvals)-1), xvals];
                    coincval = [NaN, NaN; NaN, NaN; NaN, NaN; coincval];
                else
                    if (xpeakguess>(max(xvals)-0.5))
                        xvalsnew = [xvals, (max(xvals)+1):1:(max(xvals)+3)];
                        coincval = [coincval; NaN, NaN; NaN, NaN; NaN, NaN; ];
                    else %peak sandwiched between min(xvals) and max(xvas)
                        xvalsnew = [min(xvals)-1, xvals, max(xvals)+1];
                        coincval = [NaN, NaN; coincval;  NaN, NaN; ];
                    end
                end

                xvals = xvalsnew;
                for xval = xvals
                    index = find(xval == xvalsnew);
                    if ~isnan(coincval(index,1))  %been there done that
                        continue; 
                    end

                    f_MovePiezo(currentArm, xval);       
                    RestOfTheDataString = {'Ortec Starts', 'Ortec Estimated Stops', 'Coincidence ROI', 'Afterpulse ROI', 'Small Background ROI', 'Big Background ROI'};
                    tmpData = RunOrtec(vi, nreads, {singlesStr, 'Coincidence ROI',RestOfTheDataString{:}});
                    coincval = [coincval; tmpData(1:2)];
                    plot(CoincScanAxes(cnt),xvals(1:length(coincval))', [0.1*coincval(:,1)], '-v', ...
                               xvals(1:length(coincval))',  coincval(:,2) ,     '-o');
                    h = legend(CoincScanAxes(cnt),'singles/10', 'coincs');
                    title(CoincScanAxes(cnt),ArmsNames{cnt}); 
                    set(h, 'location', 'best');
                    
                    
                    %Get Positions of theArms:
                    armvals = [(1:4)*NaN];
                    for m = 1:length(theArms)
                        [tmp, armvals(m)] = theArms(m).GetPosOutput(0,0);
                    end
                    
                    fprintf(SuperLog, ' ''%s'' \t ''%s'' \t [%2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f] \t [%2.2f, %2.2f, %2.2f, %2.2f] \t %i \t [%i, %i, %i, %i, %i, %i] \n', ...
                                starttimestr, polmessage{1}(1), knobcntr,                                 armvals,           FPGA_Gatewidth,   tmpData(3:end)                     );
                    
                    drawnow();  
                end

                [xbest errval]           = GetGaussianPeak(xvals, coincval(:,2)');
                [xbest_sing errval_sing] = GetGaussianPeak(xvals, coincval(:,1)');
                
                %possibly add 2 points for singles:
                if ( xbest_sing<=(min(xvals)+0.5) || xbest_sing>=(max(xvals)-0.5) )
                    
                    if (xbest_sing <= (min(xvals)+0.5))
                        xvalsnew = [(min(xvals)-2):1:(min(xvals)-1), xvals];
                        coincval = [NaN, NaN; NaN, NaN; coincval];      
                    else %xbest_sing >= max(xvals)-0.5
                        xvalsnew = [xvals, (max(xvals)+1):1:(max(xvals)+2)];
                        coincval = [coincval; NaN, NaN; NaN, NaN; ];                       
                    end
                    
                    xvals = xvalsnew;
                    for xval = xvals
                        index = find(xval == xvalsnew);
                        if ~isnan(coincval(index,1))  %been there done that
                            continue; 
                        end

                        f_MovePiezo(currentArm, xval);       
                        RestOfTheDataString = {'Ortec Starts', 'Ortec Estimated Stops', 'Coincidence ROI', 'Afterpulse ROI', 'Small Background ROI', 'Big Background ROI'};
                        tmpData = RunOrtec(vi, nreads, {singlesStr, 'Coincidence ROI',RestOfTheDataString{:}});
                        coincval = [coincval; tmpData(1:2)];
                        plot(CoincScanAxes(cnt),xvals(1:length(coincval))', [0.1*coincval(:,1)], '-v', ...
                                   xvals(1:length(coincval))',  coincval(:,2) ,     '-o');
                        h = legend(CoincScanAxes(cnt),'singles/10', 'coincs');
                        title(CoincScanAxes(cnt),ArmsNames{cnt}); 
                        set(h, 'location', 'best');


                        %Get Positions of theArms:
                        armvals = [(1:4)*NaN];
                        for m = 1:length(theArms)
                            [tmp, armvals(m)] = theArms(m).GetPosOutput(0,0);
                        end

                        fprintf(SuperLog, ' ''%s'' \t ''%s'' \t [%2.2f, %2.2f, %2.2f, %2.2f, %2.2f, %2.2f] \t [%2.2f, %2.2f, %2.2f, %2.2f] \t %i \t [%i, %i, %i, %i, %i, %i] \n', ...
                                    starttimestr, polmessage{1}(1), knobcntr,                                 armvals,           FPGA_Gatewidth,   tmpData(3:end)                     );

                        drawnow();         
                    end                    
                end
                
                [xbest errval tmp3 tmp4 peakcoinc(dapol)]  = GetGaussianPeak(xvals, coincval(:,2)', CoincScanAxes(cnt), 'r' );
                [xbest_sing errval_sing]            = GetGaussianPeak(xvals, coincval(:,1)', CoincScanAxes(cnt), 'b',0.1);
                
                fprintf(1, 'Going to %s-best = %2.3f +/- %2.3f   ',ArmsNames{cnt}, xbest, errval);
                fprintf(1, 'Singles  %s-best = %2.3f +/- %2.3f\n',ArmsNames{cnt}, xbest_sing, errval_sing);
                %now go to xbest:
                if (xbest>0) && (xbest<20)
                	f_MovePiezo(currentArm, xbest)  ; %move to xbest only if it is IN RANGE
                end
                bestvals = [bestvals, xbest];
                bestvals_sing = [bestvals_sing, xbest_sing];
            end % end switch between the different Axes of the Piezo actuators

            fprintf(1,'%s: [%2.2f, %2.2f, %2.2f, %2.2f]\n', polmessage{dapol},bestvals);
            if (dapol == 1)
                Hbestvals = bestvals;
                Hbestvals_sing = bestvals_sing;
            else
                Vbestvals = bestvals;
                Vbestvals_sing = bestvals_sing;
            end

            if (first_polarization)
                first_polarization = 0;
            else
                break;
            end
        end % end look at the 2 different beams (H-Pump, V-pump)



        fprintf(1,'\n\n\n%s,  stop time: %s\n', starttimestr, datestr(now, 'HH.MM.SS'));
        fprintf(1,'H-pol pump: [%02.2f, %02.2f, %02.2f, %02.2f]\n', Hbestvals);
        fprintf(1,'V-pol pump: [%02.2f, %02.2f, %02.2f, %02.2f]\n', Vbestvals);
        fprintf(1,'Diff (H-V): [%02.2f, %02.2f, %02.2f, %02.2f]\n', Hbestvals-Vbestvals);


        fprintf(1,'Norm (H-V): %2.3f\n', norm(Hbestvals-Vbestvals));
        dist1 = norm(Hbestvals-Vbestvals); 

        defaultvalues(1,:) = Hbestvals;
        defaultvalues(2,:) = Vbestvals;
        fprintf(1,'\nMedian(HV): [%02.2f %02.2f %02.2f %02.2f]\n', 0.5*(Hbestvals+Vbestvals));


        fprintf(1,'Diff Singles(H-H): [%02.2f, %02.2f, %02.2f, %02.2f], dist of %2.3f \r\n', Hbestvals-Hbestvals_sing, norm(Hbestvals-Hbestvals_sing));
        fprintf(1,'Diff Singles(V-v): [%02.2f, %02.2f, %02.2f, %02.2f], dist of %2.3f \r\n', Vbestvals-Vbestvals_sing, norm(Vbestvals-Vbestvals_sing));
        dist2 = norm(Hbestvals-Hbestvals_sing);
        dist3 = norm(Vbestvals-Vbestvals_sing);

        fprintf(Logfile, ' ''%s'' \t [%2.2f %2.2f %2.2f %2.2f %2.2f %2.2f] \t %2.2f \t %2.2f \t %2.2f \t [%2.2f %2.2f %2.2f %2.2f] \t [%2.2f %2.2f %2.2f %2.2f] \t [%2.2f %2.2f %2.2f %2.2f] \t [%2.2f %2.2f %2.2f %2.2f]  \t %4.2f \t %4.2f;\n', ...
                          starttimestr,             knobcntr,                    dist1,     dist2,   dist3,          Hbestvals,                  Vbestvals,                  Hbestvals_sing,             Vbestvals_sing  ,  peakcoinc   ); 
        scanknob_beamdist_values = [scanknob_beamdist_values; Hbestvals, Vbestvals, Hbestvals, Hbestvals_sing, Vbestvals, Vbestvals_sing, peakcoinc];        
        [tmp, index] = sort(scanknobvalues);

        dependentaxeslabels = {'Coincs Beam coords H(o) V(v) ', 'Hcoincs (o), Hsingles (v)', 'Vcoincs (o), Vsingles (v)'}
        for m = 1:3
            
            for n = 1:4
                tmpax =  tweakfigaxes(m,n) ;
                
                plot(tmpax, scanknobvalues(index), scanknob_beamdist_values(index,8*(m-1)+(n-1)+1)  , 'b-o', ...
                           scanknobvalues(index), scanknob_beamdist_values(index,8*(m-1)+(n-1)+1+4), 'r-v');
                       
                ylabel(tmpax, dependentaxeslabels{m});   
                xlabel(tmpax, sprintf('x 0.1 rev %s turns', knobnames{scanknob}));
                title(tmpax, ArmsNames{n});                                     
            end
            %5th plot is the coincidence counts... 
            tmpax = tweakfigaxes(m,5);
            if (m==1) 
                plot(tmpax, scanknobvalues(index), scanknob_beamdist_values(index,end-1), 'ro', ...
                            scanknobvalues(index), scanknob_beamdist_values(index,end),   'bv' );                
            else
                plot(tmpax, scanknobvalues(index), scanknob_beamdist_values(index,end+m-3), 'ro');                
            end
            ylabel(tmpax,'Coinc counts');
            xlabel(tmpax,sprintf('x 0.1 rev %s turns', knobnames{scanknob}));
        end        
        drawnow()
        
        
        %return control of device
        for k = 1:length(theArms)
            theArms(k).StopCtrl;
        end
        for k = 1:length(HWPaxes)
            HWPaxes(k).StopCtrl;
        end
    end %end scanknob
    
end %end tweak knob

% tic
%     for k = 1:length(theArms)
%         theArms(k).StartCtrl;
%     end    
%     for k = 1:length(HWPaxes)
%         HWPaxes(k).StartCtrl;
% %         HWPaxes(k).EnableHWChannel(0);
%     end
% toc


fclose(Logfile);