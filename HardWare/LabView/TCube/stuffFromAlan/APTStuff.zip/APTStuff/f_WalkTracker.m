%This is Working Code... 
% Mar 01... working... well
%
%
% useage:  f_WalkTracker(filename, howmanyfigs)
%
% filename = string, howmanyfigs = how many to display 
%
%dependencies:
%

function fighandles = f_WalkTracker(filename, displayhowmany)

    if (~exist('displayhowmany', 'var'))
        displayhowmany = 9999999;
    end
        
    %assume file is in current working directory
    fid = fopen(filename);

    k = 0;
    filesize = f_filesize(filename);
    RelevantData = [];
    CountData = [];
    while ~feof(fid) % read all the old stuff first... 
        dastr = fgetl(fid);
        if isempty(dastr)
            continue % empty string... 
        end

        %get rid of white spaces
        while (dastr(1) == ' ') 
            dastr = dastr(2:end);
        end

        while (dastr(end) == ' ') 
            dastr = dastr(1:(end-1));
        end    

        if dastr(1) == '%'
            %this is a comment line
            continue;
        else
            acell = eval(sprintf('{%s}',dastr));
            %                           knob values   
            RelevantData = [RelevantData; acell{2},     acell{6},   acell{7}];
            CountData = [CountData; acell{10} acell{11} acell{12}*1e4 acell{13}*1e4];
        end

    end

%     RelevantData

    %parse thru' the data... which knobs are being turned?  
    %do this for the static case first... 
    %

    %identify which 2 knobs are being walked... 
    numpoints = length(RelevantData(:,1));  % total # of data points
    index = 1;
    currentknobs = [];

    PlottedData = [];

    knobnames = {'M1B', 'M1C', 'M1T', 'M2B', 'M2C', 'M2T'};


    fighandles = [];
    numfigs = 0;
    while (index<numpoints)

        % new plot
        numfigs = numfigs+1;
        [fighandles(numfigs), ax] = Walk_CreateNewPlot();    


        start = index;
        stop = [];

        while (isempty(stop))
            knobchange = RelevantData(index+1,1:6) - RelevantData(index,1:6);
            whichknobs = find(knobchange~=0);                  

            switch length(whichknobs)
                case (0)
                    % this (index+1) point is part of the plot
                case (1)
                    if (whichknobs<4)
                        whichknobs = [whichknobs,   whichknobs+3];
                    else
                        whichknobs = [whichknobs-3, whichknobs];
                    end
                    if isempty(currentknobs)
                        currentknobs = whichknobs;
                    else
                        if sum(currentknobs == whichknobs) == 2 %same settings
                            % do nothing... let this guy increment
                        else % different settings... need to move onto a new plot
                            %currentknobs = whichknobs; 
                            % we can't update the current knobs yet...
                            stop = index;
                        end
                    end                
                case (2)      
                    if sum(sort(currentknobs) == sort(whichknobs)) == 2
                        %continue on;                    
                    else % different knobs changed
                        stop = index;
                        currentknobs = whichknobs;
                    end
                otherwise % more than 2 knobs changed...  
                    stop = index;
            end


            if (index == (numpoints-1) && isempty(stop))
                stop = index+1;
                index == index+1;
            else
                index = index+1;
            end

            if ~isempty(stop)
                index = stop;
                break;
            end
%             currentknobs
        end


        power = 2;
        if ((stop-start ) > 20) 
            %plot only the last 10... 
            start = stop - 20;
        end
%         fprintf(1, 'start %i stop %i\n', start, stop);
        %plot everything from start --> stop  
        hold(ax(1), 'on')
            plot3(ax(1), RelevantData(start:stop, currentknobs(1)), RelevantData(start:stop, currentknobs(2)), start:stop, '-b'); % this subplot details the knob configurations
            scatter3(ax(1), RelevantData(start:stop, currentknobs(1)), RelevantData(start:stop, currentknobs(2)), start:stop,1000*(([start:stop]'+(1-start))/(stop-start+1)).^power, 'b'); % this subplot details the knob configurations            
        hold(ax(1), 'off')
        xlabel(ax(1), sprintf('%s knob', knobnames{currentknobs(1)}));
        ylabel(ax(1), sprintf('%s knob', knobnames{currentknobs(2)}));

        hold(ax(2), 'on');        
            sh1 = scatter(ax(2), RelevantData(start:stop, 7),     RelevantData(start:stop, 8), 500*(([start:stop]'+(1-start))/(stop-start+1)).^power , 'b'); 
            sh2 = scatter(ax(2), RelevantData(start:stop, 11),    RelevantData(start:stop, 12),500*(([start:stop]'+(1-start))/(stop-start+1)).^power, 'r'); 
            plot(ax(2), RelevantData(start:stop, 7), RelevantData(start:stop, 8), '-b'); 
            plot(ax(2), RelevantData(start:stop, 11), RelevantData(start:stop, 12), '-r'); 
            title(ax(2), 'ArmA');
            leg = legend(ax(2), 'H-pol', 'V-pol');
            set(leg, 'Location', 'Best');
        hold(ax(2), 'on');


        hold(ax(3), 'on');
            sh1 = scatter(ax(3), RelevantData(start:stop, 9),     RelevantData(start:stop, 10), 500*(([start:stop]'+(1-start))/(stop-start+1)).^power , 'b'); 
            sh2 = scatter(ax(3), RelevantData(start:stop, 13),    RelevantData(start:stop, 14), 500*(([start:stop]'+(1-start))/(stop-start+1)).^power, 'r');     
            plot(ax(3), RelevantData(start:stop, 9), RelevantData(start:stop, 10), 'b'); % this subplot details the knob configurations
            plot(ax(3), RelevantData(start:stop, 13), RelevantData(start:stop, 14), 'r'); % this subplot details the knob configurations
            title(ax(3), 'ArmB');
            leg = legend(ax(3), 'H-pol', 'V-pol');
            set(leg, 'Location', 'Best');
        hold(ax(3), 'on');    

        
        hold(ax(4), 'on');
            knobvalues =  RelevantData(start:stop, currentknobs)';
            
            [axcounts,H1,H2] = plotyy(ax(4), start:stop, knobvalues, ....
                          start:stop, CountData(start:stop,:));
            set(H1(1), 'Marker', 'd');
            set(H1(2), 'Marker', 'd');
            set(H2(1), 'Marker', 'o', 'LineStyle', 'o', 'Color', 'r');          
            set(H2(2), 'LineStyle', 's', 'Color', 'b' );          
            set(H2(3), 'LineStyle', '^', 'Color', 'k' );          
            set(H2(4), 'LineStyle', 'v', 'Color', 'g' );          
            leg = legend(sprintf('Knob %s', knobnames{currentknobs(1)}), sprintf('Knob %s', knobnames{currentknobs(2)}), ...
                         'Coincs H', 'Coincs V', 'Heralding Eff*1e4');
                     set(leg, 'Location', 'Best');
        hold(ax(4), 'off');
        
        
        hold(ax(5), 'on');
                %ArmA data:  
             distA = sqrt( (RelevantData(start:stop, 7)- RelevantData(start:stop, 11)).^2 + (RelevantData(start:stop, 8)- RelevantData(start:stop, 12)).^2 );
             distB = sqrt( (RelevantData(start:stop, 9)- RelevantData(start:stop, 13)).^2 + (RelevantData(start:stop, 10)- RelevantData(start:stop, 14)).^2 );
        %ArmB data:  RelevantData(start:stop, 9:10) for H   RelevantData(start:stop, 13:14) V
            plot(ax(5),start:stop, distA, '-bo');
            plot(ax(5),start:stop, distB, '-kv');
            leg = legend(ax(5),'Dist for ArmA', 'ArmB');
        hold(ax(5), 'off');
    % 
    %     % we will assume that point (index) was previously plotted already... 
    % 
    %     %adding a new data point to the x-data
    % %     set(h, 'XData', [get(h, 'XData'), newvalX])
    % %     set(h, 'YData', [get(h, 'YData'), newvalY])
    % %   where previously, 
    %     

        index = index+1;
        set(fighandles(numfigs), 'name',sprintf('Walking  %s x %s ', knobnames{currentknobs(1)}, knobnames{currentknobs(2)}) );        
        currentknobs = whichknobs;% after we've plotted everything THEN update
    end
    
    %close all except the last howmany
    for k = 1:(numfigs-displayhowmany)
        close(fighandles(k));
    end
        
end
