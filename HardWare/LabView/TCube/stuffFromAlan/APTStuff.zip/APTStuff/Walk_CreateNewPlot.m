

function [fighandle, axes] = Walk_CreateNewPlot()

    fighandle = figure;
    axes(1) = subplot(3,3,1);
    axes(2) = subplot(3,3,2);
    axes(3) = subplot(3,3,3);
    axes(4) = subplot(3,3,4:6);
    axes(5) = subplot(3,3,7:9);
    
end
