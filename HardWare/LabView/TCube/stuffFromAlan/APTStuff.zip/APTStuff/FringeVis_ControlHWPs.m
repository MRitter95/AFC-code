%dependencies:
%   f_MoveHWP
%   InitializeAxis
%   RunOrtec
%   GetSinusoidalVis
%


clearvars -except dapol Zeroed defaultvalues; close all; clc

format short 



%start the Ortec Card interface:
e=actxserver('LabVIEW.Application');
vipath='C:\Users\pdclab\Desktop\UBER program from Ware modified for FPGA\Coincidence VI, New\Take Data AM2.vi';
vi=invoke(e,'GetVIReference',vipath);




% [year month day hour minute seconds]
clock2sec = @(clock) clock(end) + 60*clock(end-1) + 3600*clock(end-2) + 24*3600*clock(end-3);



%initialize the APT controller HWPs

IsMoving = @(StatusBits) bitget(abs(StatusBits),5)||bitget(abs(StatusBits),6);

HWPnames = {'Pump', 'ArmA', 'ArmB'};
anglesettings = [[275, 308, 186]; ...
                [320, 354, 232]];
serialnumbers = [83840800, 83838157, 83837795];


fpos = get(0, 'DefaultFigurePosition');
% fpos(3) = 400;
% fpos(4) = 900;

f = figure('Position', fpos);


HWPaxes(1) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20 400 380 180]); % pump
HWPaxes(2) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20 200 380 180]); % ArmA
HWPaxes(3) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20  20 380 180]); % ArmB

for k = 1: 3%%length(HWPaxes)
    HWPaxes(k).StartCtrl;
    set(HWPaxes(k),'HWSerialNum', serialnumbers(k));
%     HWPaxes(k).Identify;
    pause(5);
    HWPaxes(k).DisableHWChannel(0);
    pause(1);
    HWPaxes(k).EnableHWChannel(0);
end
drawnow();


%zero
if (~exist('Zeroed'))
    Zeroed = 0;
end

pause (5); % wait for GUI shit to load

if (~Zeroed)
    parfor k = 1:3%:length(HWPaxes)
        HWPaxes(k).MoveHome(0,0);
        tic
        while (IsMoving(HWPaxes(k).GetStatusBits_Bits(0)) || (abs(HWPaxes(k).GetPosition_Position(0)-0)>0.001))
            datime = toc
            if (datime >30)
                break;
            end
        end % wait!
    end
    Zeroed = 1;
end




nreads = 2;  % 2 data points per setting... 





%ArmB activate as well


if ~exist('defaultvalues')
    defaultvalues = [12, 9, 13.2, 8.5]
else
    defaultvalues
end
fighandleAX = figure('name', 'ArmA-X');
ArmA(1) = InitializeAxis(91858837, fighandleAX, defaultvalues(1));

fighandleAZ = figure('name', 'ArmA-Z');
ArmA(3) = InitializeAxis(91858839, fighandleAZ, defaultvalues(2));

fighandleBX = figure('name', 'ArmB-X');
ArmB(1) = InitializeAxis(91814391, fighandleBX, defaultvalues(3));

fighandleBZ = figure('name', 'ArmB-Z');
ArmB(3) = InitializeAxis(91814393, fighandleBZ, defaultvalues(4));


% depth3 = {'Right-Hand Rotate 1/10 rotation'; ' Left-Hand Rotate 1/10 rotation'};
polchangemessage = {'Polarization Change: Go to H-V-H'; 'Polarization Change: Go to V-H-V'};
polmessage =        {'H-pol pump results: '           ; 'V-pol pump results: '};

theArms = [ArmA(1), ArmA(3),        ArmB(1), ArmB(3)];
ArmsNames = {'ArmA-x'; 'ArmA-z';    'ArmB-X'; 'ArmB-Z'};

Hbestvals = [];
Vbestvals = [];


Psettings = 297.5;
f_MoveHWP(HWPaxes(1),Psettings);
pause(3);
Asettings = 354 - [0:22.5:67.5];
Bsettings = 186 + [0:5.625:90];


coincval = [];
for Asetting = Asettings

    f_MoveHWP(HWPaxes(2), Asetting);
    figure('name', sprintf('Fringes ArmA = %2.2f', Asetting));
    figax = gca;
    if isempty(coincval)
        startpoint = 1;
    else
        startpoint = length(coincval(:,1))+1;
    end
    
    for Bsetting = Bsettings
        settings = [Asetting, Bsetting];
        f_MoveHWP(HWPaxes(3), Bsetting);
                
        % A singles, B singles, Coincidence...                                                    
        coincval = [coincval; Psettings, settings, RunOrtec(vi, nreads, {'Ortec Starts', 'Ortec Estimated Stops', 'Coincidence ROI'})];
        
        plot(coincval(startpoint:end,3), coincval(startpoint:end,4)/10, '^', ...
             coincval(startpoint:end,3), coincval(startpoint:end,5)/10, 'v', ...
             coincval(startpoint:end,3), coincval(startpoint:end,6), '*'             );
        legend('ArmA/10/sec','ArmB/10/sec','Coincs/sec');     
        drawnow();
    end
       
    [Vis, errVis,PeakCounts,LSval] = GetSinusoidalVis(coincval(startpoint:end,3), coincval(startpoint:end,end), figax);
    fprintf('Visibility of (ArmA = %2.2f): %2.4f +/- %2.4f, at a peak of %4.2f cps\n', Asetting, Vis, errVis, PeakCounts);
    
end


