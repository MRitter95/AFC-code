%Modified Feb 25, 2016
%
%useage: knobvalue = TakeKnobInput()
%
%This should not crash... hopefully... 
%
%3 choices of input:
%a)  Functionally (ItoA(5))
%
%Dependencies: AtoI


function knobval = TakeKnobInput(knobname)


    characters = '0123456789ABCDEFGHIJKLMNOPQRS';


    knobstr = [];
    knobval = [];
    while (isempty(knobstr))
        knobstr = input(sprintf('What is knob %s value? Give in {cell} form: ',knobname), 's');

        if isempty(knobstr)
            continue;
        end
        
        if (~isempty(strfind(upper(knobstr), 'NAN')))
            knobval = NaN;            
            break; % not a number detected!!!
        end
        
        
        while (knobstr(1)==' ')%get rid of white spaces at beginning... 
            knobstr = knobstr(2:end);
        end
        while (knobstr(end)==' ')%get rid of white spaces at the end... 
            knobstr = knobstr(1:(end-1));
        end
 
        
        IsItNumeric = 0;
        
        try            
            IsItNumeric = isnumeric(eval(knobstr));
        catch% error! not numeric or not evaluable... 
            IsItNumeric = 0;  % could be something like '5++'
        end
 
        if IsItNumeric
            knobval = eval(knobstr);
        else
            evaluable = 0;
            try
                eval(knobstr);
                evaluable = 1;
            catch
                evaluable = 0;
            end
            
            if evaluable % probably contains quotes already
                try
                    knobval = AtoI(eval(knobstr)); % knobstr now looks like a cell 
                catch % all errors
                    knobstr = [];
                    knobval = [];
                    fprintf(1, 'invalid form \n');
                    continue;
                end
            end
        end
        
        

        if (length(knobval)~=1)
            knobstr = [];
            knobval = [];
            fprintf(1, 'more than 1 element \n');
        end
    end

end
