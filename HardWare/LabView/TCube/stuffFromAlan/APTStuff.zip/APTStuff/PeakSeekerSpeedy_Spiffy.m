%PeakSeekerSpeedy_Spiffy.m updated Feb 04 2016
%dependencies:
%
%InitializeAxis.m %% for Piezo
% f_MoveHWP.m  %% for moving HWP rotation mounts...
%RunOrtec.m
%GetGaussianPeak.m (which in turn depends on)
% errorfunc.m


%is there a way we can speed things up? 
clearvars -except dapol Zeroed defaultvalues    HWPguifig HWPaxes   PiezoGUIfigs theArms ; 


Logfilename = sprintf('LogOfMoves.%s.txt', datestr(now,'YYYY-MM-DD'));
Logfile = fopen(Logfilename, 'a');
%Log file for recording all the knob turns... 


%delete all figures except... HWPguifig and PiezoGUIfigs
all_figs = findall(0, 'type', 'figure');
figstoexclude = []; %figures that we DON'T want closed... 
if (exist('HWPguifig','var') && exist('HWPaxes','var') && exist('PiezoGUIfigs','var') && exist('theArms','var')) % both the GUI windows for waveplates and 
    setdiff(all_figs, [HWPguifig, PiezoGUIfigs])
    delete(setdiff(all_figs, [HWPguifig, PiezoGUIfigs])); % delete everything except the gui interfaces for the various axes
else
    clear HWPguifig HWPaxes   PiezoGUIfigs theArms ;
    close all;
end


format short 
starttimestr = sprintf('start time: %s', datestr(now, 'HH.MM.SS'));
fprintf(1, 'start time: %s\n', datestr(now, 'HH.MM.SS'));


%start the Ortec Card interface:
e=actxserver('LabVIEW.Application');
vipath='C:\Users\pdclab\Desktop\UBER program from Ware modified for FPGA\Coincidence VI, New\Take Data AM2.vi';
vi=invoke(e,'GetVIReference',vipath);




% [year month day hour minute seconds]
clock2sec = @(clock) clock(end) + 60*clock(end-1) + 3600*clock(end-2) + 24*3600*clock(end-3);



%initialize the APT controller HWPs

IsMoving = @(StatusBits) bitget(abs(StatusBits),5)||bitget(abs(StatusBits),6);

HWPnames = {'Pump', 'ArmA', 'ArmB'};
anglesettings = [[275, 308, 186]; ...
                [320, 354, 232]];
serialnumbers = [83840800, 83838157, 83837795];




fpos = get(0, 'DefaultFigurePosition');
if (~exist('HWPguifig','var') || ~exist('HWPaxes','var')) % don't need to re-initialize  all the axes...
    HWPguifig = figure('Position', fpos,'name', 'HWP + Piezo controllers');

    for k = 1: 3%%length(HWPaxes)
        HWPaxes(k) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20 (3-k)*200 320 180]); 
        %
        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [150 [(4-k)*200-50] 50 20] );
        set(mTextBox,'String',HWPnames{k});
       
        %
        HWPaxes(k).StartCtrl;
        set(HWPaxes(k),'HWSerialNum', serialnumbers(k));
    %     HWPaxes(k).Identify;
        pause(5);
        HWPaxes(k).DisableHWChannel(0);
        pause(1);
        HWPaxes(k).EnableHWChannel(0);
    end
    drawnow();
        
    pause (5); % wait for GUI shit to load    
end


%zero
if (~exist('Zeroed'))
    Zeroed = 0;
end


if (~Zeroed)
    parfor k = 1:3%:length(HWPaxes)
        HWPaxes(k).MoveHome(0,0);              
    end
    
    coords = zeros(1,3);
    tic
    while(1)
        for k = 1:3
            coords(k) = HWPaxes(k).GetPosition_Position(0);
        end
        if (norm(coords)<0.002)
            break;
        end        
        datime = toc; 
        if (datime>60)
            break;
        end
    end        
    Zeroed = 1;
end




nreads = 1;  % 1 data point, 2 second integration time/data point





%activate the piezo axes... 

if ~exist('defaultvalues')
    defaultvalues =     [5.8839    8.7621   12.0415    7.9676]
else
    defaultvalues
end


ArmsNames = {'ArmA-x';      'ArmA-z';    'ArmB-X'; 'ArmB-Z'};
PiezoSerials = [91858837,   91858839,   91814391, 91814393];


if (~exist('PiezoGUIfigs') || ~exist('theArms'))  %PiezoGUIfigs theArms
    theArms = [];
    PiezoGUIfigs = HWPguifig; %figure('name','Piezo Controllers');
    for k = 1:length(ArmsNames)
        figplacement = [350 ((length(ArmsNames)-k)*200) 250 180];
        tmp = InitializeAxis(PiezoSerials(k), PiezoGUIfigs, defaultvalues(k), figplacement);
        theArms = [theArms,tmp];5

        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [figplacement(1)+100, ((length(ArmsNames)-k+1)*200-40) 50 20] );
        set(mTextBox,'String',ArmsNames{k});         
    end
end






% depth3 = {'Right-Hand Rotate 1/10 rotation'; ' Left-Hand Rotate 1/10 rotation'};
polchangemessage = {'Polarization Change: Go to H-V-H'; 'Polarization Change: Go to V-H-V'};
polmessage =        {'H-pol pump results: '           ; 'V-pol pump results: '};



Hbestvals = [];
Vbestvals = [];

first_iteration = 1;



while(1)


    currenthwps = [HWPaxes(1).GetPosition_Position(0), HWPaxes(2).GetPosition_Position(0), HWPaxes(3).GetPosition_Position(0)];
    if (first_iteration)
        if norm(currenthwps-anglesettings(1,:))<=0.01
            dapol = 1; % H-pump
        else
            dapol = 2; % V-pump
        end
    else
         dapol = 3-dapol;
%          input(polchangemessage{dapol}, 's');
    end

    figure('name', polmessage{dapol}); 
    for k = 1:4
        subplot(2,2,k);
        CoincScanAxes(k) = gca;
    end    



    whichPols = dapol; % 1 for H, 2 for V

    %which set of polarizations to change to?
    f_MoveHWP(HWPaxes , anglesettings(whichPols,:));  % move all 3 rotation mounts at once
%     parfor k =1:length(HWPaxes)
%         f_MoveHWP(HWPaxes(k), anglesettings(whichPols,k));
%     end    

    bestvals = [];
    bestvals_sing = [];
    for cnt = 1:length(theArms)

        currentArm = theArms(cnt);
%         [tmp, x0] = currentArm.GetPosOutput(0,0);
        x0 = defaultvalues(cnt);

        xvals = x0+linspace(-1,1,3);

        if (max(xvals)>20)
            xvals = xvals - (max(xvals)-20);
        end

        coincval = [];
        title(CoincScanAxes(cnt),ArmsNames{cnt}); 
        currentArm.SetPosOutput(0, min(xvals));


        if (cnt<=2) % Look at ArmA singles as well... 
            singlesStr = 'Ortec Starts';
        else  %Look at ArmB singles...
            singlesStr = 'Ortec Estimated Stops';
        end

        for xval = xvals

            f_MovePiezo(currentArm, xval)       


            coincval = [coincval; RunOrtec(vi, nreads, {singlesStr, 'Coincidence ROI'})];
            plot(CoincScanAxes(cnt),xvals(1:length(coincval))', [0.1*coincval(:,1)], '-v', ...
                       xvals(1:length(coincval))',  coincval(:,2) ,     '-o');
            h = legend(CoincScanAxes(cnt),'singles/10', 'coincs');
            title(CoincScanAxes(cnt),ArmsNames{cnt}); 
            set(h, 'location', 'best');
            drawnow();
        end

        % we have 3 points... let's fit it to a Gaussian...  
        [xpeakguess errval]           = GetGaussianPeak(xvals, coincval(:,2)');
        if (xpeakguess<min(xvals))
            xvalsnew = [(min(xvals)-3):1:(min(xvals)-1), xvals];
            coincval = [NaN, NaN; NaN, NaN; NaN, NaN; coincval];
        else
            if (xpeakguess>max(xvals))
                xvalsnew = [xvals, (max(xvals)+1):1:(max(xvals)+3)];
                coincval = [coincval; NaN, NaN; NaN, NaN; NaN, NaN; ];
            else %peak sandwiched between min(xvals) and max(xvas)
                xvalsnew = [min(xvals)-1, xvals, max(xvals)+1];
                coincval = [NaN, NaN; coincval;  NaN, NaN; ];
            end
        end

        xvals = xvalsnew;
        for xval = xvals
            index = find(xval == xvalsnew);
            if ~isnan(coincval(index,1))  %been there done that
                continue; 
            end

            f_MovePiezo(currentArm, xval)'               
            
            coincval(index,:) = [ RunOrtec(vi, nreads, {singlesStr, 'Coincidence ROI'})];
            plot(CoincScanAxes(cnt),xvals, [0.1*coincval(:,1)], '-v', ...
                       xvals,  coincval(:,2) ,     '-o');
            h = legend(CoincScanAxes(cnt),'singles/10', 'coincs');
            title(CoincScanAxes(cnt),ArmsNames{cnt}); 
            set(h, 'location', 'best');
            drawnow();            
        end



        [xbest errval]           = GetGaussianPeak(xvals, coincval(:,2)');
        [xbest_sing errval_sing] = GetGaussianPeak(xvals, coincval(:,1)');
        fprintf(1, 'Going to %s-best = %2.3f +/- %2.3f   ',ArmsNames{cnt}, xbest, errval);
        fprintf(1, 'Singles  %s-best = %2.3f +/- %2.3f\n',ArmsNames{cnt}, xbest_sing, errval_sing);
        %now go to xbest:
        f_MovePiezo(currentArm, xbest)   
        bestvals = [bestvals, xbest];
        bestvals_sing = [bestvals_sing, xbest_sing];
    end

    fprintf(1,'%s: [%2.2f, %2.2f, %2.2f, %2.2f]\n', polmessage{dapol},bestvals);
    if (dapol == 1)
        Hbestvals = bestvals;
        Hbestvals_sing = bestvals_sing;
    else
        Vbestvals = bestvals;
        Vbestvals_sing = bestvals_sing;
    end



    if (first_iteration)
        first_iteration = 0;
    else
        break;
    end
end



fprintf(1,'\n\n\n%s,  stop time: %s\n', starttimestr, datestr(now, 'HH.MM.SS'));
fprintf(1,'H-pol pump: [%02.2f, %02.2f, %02.2f, %02.2f]\n', Hbestvals);
fprintf(1,'V-pol pump: [%02.2f, %02.2f, %02.2f, %02.2f]\n', Vbestvals);
fprintf(1,'Diff (H-V): [%02.2f, %02.2f, %02.2f, %02.2f]\n', Hbestvals-Vbestvals);

fprintf(1,'Norm (H-V): %2.3f\n', norm(Hbestvals-Vbestvals));

defaultvalues = 0.5*Hbestvals + 0.5*Vbestvals;
fprintf(1,'\nMedian(HV): [%02.2f %02.2f %02.2f %02.2f]\n', 0.5*(Hbestvals+Vbestvals));


fprintf(1,'Diff Singles(H-H): [%02.2f, %02.2f, %02.2f, %02.2f], dist of %2.3f \n', Hbestvals-Hbestvals_sing, norm(Hbestvals-Hbestvals_sing));
fprintf(1,'Diff Singles(V-v): [%02.2f, %02.2f, %02.2f, %02.2f], dist of %2.3f \n', Vbestvals-Vbestvals_sing, norm(Vbestvals-Vbestvals_sing));
