

function [fighandle, axes] = Walk_CreateNewPlot()

    fighandle = figure;
    axes(1) = subplot(1,3,1);
    axes(2) = subplot(1,3,2);
    axes(3) = subplot(1,3,3);

end