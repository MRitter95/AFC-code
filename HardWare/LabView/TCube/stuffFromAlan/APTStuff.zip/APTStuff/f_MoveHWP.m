%useage: f_MoveHWP(hwphandle, anglevalue)
%
%       rotate hwphandle to the angle 'anglevlue'
%       we can rotate a bunch of the waveplates together... 
%         just give the handles for the axes and their desired values in
%         array form
%       

function f_MoveHWP(hwphandle, anglevalue) %#ok


    IsMoving = @(StatusBits) bitget(abs(StatusBits),5)||bitget(abs(StatusBits),6);

    for k = 1:min([length(hwphandle), length(anglevalue)])
        hwphandle(k).SetAbsMovePos(0,anglevalue(k));  
        hwphandle(k).MoveAbsolute(0,0);     
    end

    
%     tic
    fprintf(1, 'Moving %i waveplate(s) ',min([length(hwphandle), length(anglevalue)]));
    pos = [];
    while (1)        
 
        for k = 1:length(hwphandle) 
            pos(k) = hwphandle(k).GetPosition_Position(0);
        end

        if norm(pos-anglevalue)<0.1
            break;
        end
    end % wait!    
    fprintf(1, 'Done!\n');
    pause(0.5);
end