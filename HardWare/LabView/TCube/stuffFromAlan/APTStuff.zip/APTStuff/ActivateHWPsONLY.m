

%we need error bars for the peaks... 
clearvars -except dapol Zeroed defaultvalues    HWPguifig HWPaxes   PiezoGUIfigs theArms tweakfig NumRuns; 


%delete all figures except... HWPguifig and PiezoGUIfigs
all_figs = findall(0, 'type', 'figure');
figstoexclude = []; %figures that we DON'T want closed... 
if (exist('HWPguifig','var') && exist('HWPaxes','var') && exist('PiezoGUIfigs','var') && exist('theArms','var')) % both the GUI windows for waveplates and 
     setdiff(all_figs, [HWPguifig, PiezoGUIfigs])
    if ~exist('tweakfig') tweakfig =[]; end
    delete(setdiff(all_figs, [HWPguifig, PiezoGUIfigs, tweakfig])); % delete everything except the gui interfaces for the various axes
else
    clear HWPguifig HWPaxes   PiezoGUIfigs theArms ;
    close all;
end



format short 
starttimestr = sprintf('start time: %s', datestr(now, 'HH.MM.SS'));
fprintf(1, 'start time: %s\n', datestr(now, 'HH.MM.SS'));



% [year month day hour minute seconds]
clock2sec = @(clock) clock(end) + 60*clock(end-1) + 3600*clock(end-2) + 24*3600*clock(end-3);



%initialize the APT controller HWPs

HWPnames = {'Sagnac HWP','Pump', 'ArmA', 'ArmB'};
% anglesettings = [[275, 308, 186]; ...
%                 [320, 354, 232]];
anglesettings = [[290 297.5, 308, 186]; ...
                 [290 297.5, 354, 232]   ];
serialnumbers = [83836091, 83840800, 83825657, 83835882];

% for k = 1:length(HWPnames)
%     mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [150 [(5-k)*200-50] 50 20] );
%     set(mTextBox,'String',HWPnames{k});
% end


fpos = get(0, 'DefaultFigurePosition');
if (~exist('HWPguifig','var') || ~exist('HWPaxes','var')) % don't need to re-initialize  all the axes...
    HWPguifig = figure('Position', fpos,'name', 'HWP + Piezo controllers');
        set(gcf, 'closer', '');
    for k = 1:length(HWPnames)
        HWPaxes(k) = actxcontrol('MGMOTOR.MGMotorCtrl.1', [20 (4-k)*200 320 180]); 
        %
        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [150 [(5-k)*200-50] 50 20] );
        set(mTextBox,'String',HWPnames{k});
        
        %
        HWPaxes(k).StartCtrl;
        set(HWPaxes(k),'HWSerialNum', serialnumbers(k));
    %     HWPaxes(k).Identify;
        pause(5);
%         HWPaxes(k).DisableHWChannel(0);
        pause(1);
        HWPaxes(k).EnableHWChannel(0);
%         set(gcf, 'closer', '');
    end
    drawnow();
        
    pause (5); % wait for GUI shit to load    
else %otherwise just start the GUI again
    for k = 1:length(HWPaxes)
        HWPaxes(k).StartCtrl;
    end    
end



%zero
if (~exist('Zeroed'))
    Zeroed = 0;
end


if (~Zeroed)
    parfor k = 1:length(HWPaxes)
        HWPaxes(k).MoveHome(0,0);              
    end
    
    coords = zeros(1,length(HWPaxes));
    tic
    while(1)
        for k = 1:length(HWPaxes)
            coords(k) = HWPaxes(k).GetPosition_Position(0);
        end
        if (norm(coords)<0.002)
            break;
        end        
        datime = toc; 
        if (datime>60)
            break;
        end
    end        
    Zeroed = 1;
end





close(get(0,'children'));
%maybe DON't shut this guy off?
    
%remember to shut everything off if program crashes


break;


for k = 1:length(HWPaxes)
    HWPaxes(k).StopCtrl;
end    


