%modified Feb 10 2016
%
% Initialize Thorlabs Piezo Controller
%useage: [AxisHandle] = InitializeAxis(SerialNo, fighandle, InitPos, figplacement)

% SerialNo = serial # of the controller (for that particular axis), in
% numerical form (unsigned int64)
%
% fighandle = which figure do you want to dump the GUI into?
% InitPos = initial position (in microns) of the axis
%
%figplacement - where in the figure should we put the GUI?


function [AxisHandle] = InitializeAxis(SerialNo, fighandle, InitPos, figplacement)
%     gcf = fighandle;
    
    if ~exist('figplacement')
        figplacement = [20 20 380 270];
    end
    
    AxisHandle = actxcontrol('MGPIEZO.MGPiezoCtrl.1', figplacement,fighandle);
    
    AxisHandle.StartCtrl;
    
    %set serial #
    set(AxisHandle,'HWSerialNum', SerialNo); 
    
    
    %set the input source... 
    AxisHandle.SetIPSource(0,5);
    %1 = SW only, %4 = BNC + SW, %5 = Pot + SW, %6 = BNC + Pot + SW    
    
    
    AxisHandle.SetVoltPosDispMode(0,2); % 2 for microns
    
    
    AxisHandle.SetControlMode(0,4);%3 for open-loop, 4 for closed loop

    if (~isempty(InitPos))
        AxisHandle.SetPosOutput(0, InitPos);
    end
    
            
end