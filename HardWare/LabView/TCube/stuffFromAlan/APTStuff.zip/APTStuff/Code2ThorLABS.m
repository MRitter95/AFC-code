%Code2ThorLABS.m updated Feb 26 2016


for k = 1:4
    try
        theArms(k).StopCtrl;
    end
end




clear all; close all; clc


format short 
starttimestr = sprintf('start time: %s', datestr(now, 'HH.MM.SS'));
fprintf(1, 'start time: %s\n', datestr(now, 'HH.MM.SS'));



%initialize the APT Tcube TDCs controlling the HWPs



fpos = get(0, 'DefaultFigurePosition');








if ~exist('defaultvalues')
    defaultvalues = [ ...
            10  10  10  10
                    ];
else
    defaultvalues
end



%activate the piezo axes... 




ArmsNames = {'ArmA-x';      'ArmA-z';    'ArmB-X'; 'ArmB-Z'};
PiezoSerials = [91858837,   91858839,   91814391, 91814393];


if (~exist('PiezoGUIfigs') || ~exist('theArms'))  %PiezoGUIfigs theArms
    theArms = [];
    PiezoGUIfigs = figure('Position', fpos,'name', 'Piezo controllers'); %figure('name','Piezo Controllers');
    for k = 1:length(ArmsNames)
        figplacement = [350 ((length(ArmsNames)-k)*200) 250 180];
        tmp = InitializeAxis(PiezoSerials(k), PiezoGUIfigs, defaultvalues(1,k), figplacement);
        theArms = [theArms,tmp];

        mTextBox = uicontrol('style','text', 'Units', 'pixels' , 'Position', [figplacement(1)+100, ((length(ArmsNames)-k+1)*200-40) 50 20] );
        set(mTextBox,'String',ArmsNames{k});         
    end
end


%initialize all these guys:
for k = 1:length(theArms)
    theArms(k).StartCtrl;
    theArms(k).SetIPSource(0,5); % allow only POT and software input
    theArms(k).SetVoltPosDispMode(0,2); % 2 for microns
    theArms(k).SetControlMode(0,4);%3 for open-loop, 4 for closed loop
end    


%wait for shutdown signal... 
shutitdown = 0;
while (~shutitdown)
    try
        shutitdown = input('Shutdown? (0 or 1) \n');
    catch
        shutitdown = 0;
    end
    if isempty(shutitdown) 
        shutitdown = 0;
    end
end




%remember to shut everything off if program crashes
for k = 1:length(theArms)
    theArms(k).StopCtrl;
end
