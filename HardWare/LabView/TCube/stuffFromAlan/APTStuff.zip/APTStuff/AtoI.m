%Modified Feb 25 2016
%
% convert alpha-numeric knob reading to integer knob reading ...
%
%
%each knob position is labeled from '0' (0) to 'S' (28)
% how do we deal with issues of 'wrap around'?
% if value is <0,or >28, how do we deal with it?  
%we deal with it by adding additional characters, 3++ means 3+2*29
% S- = -1
% so now, the output for ItoA will be an array ONLY if all values or
% between 0 and 28
%
% Note: '0-' is equivalent to '0', but '0--' is equivalent to a numerical value of -29
%
%useage:    thisnum = AtoI(thischarArray)
%
%characters cannot have white spaces!!!!

function thisnum = AtoI(thischarArray)

    characters = '0123456789ABCDEFGHIJKLMNOPQRS';
    dabase = length(characters);

    
    if (iscell(thischarArray))
        
        for k = 1:length(thischarArray)            
            thischar = upper(thischarArray{k});
            if (length(thischar)>1)
                dasymbol = thischar(2);
                numsymbols = length(strfind(thischar, dasymbol));
                
                if dasymbol == '+'
                    thisnum(k) = dabase*numsymbols + strfind(characters, thischar(1))-1;
                else % '-'
                    if dasymbol == '-'
                        if (thischar(1) ~= '0')
                            thisnum(k) = -dabase*(numsymbols) + strfind(characters, thischar(1))-1;
                        else% the character is '0'
                            thisnum(k) = -dabase*(numsymbols-1);
                        end
                    end
                end
            else % just 1 character
                thisnum(k) =  strfind(characters, thischar(1))-1;
            end           
        end
        
    else % still an array...
        
        for k = 1:length(thischarArray)
            thischar = thischarArray(k);
            tempnum = strfind(characters, upper(thischar))-1;
            if ~isempty(tempnum)
                thisnum(k) = tempnum;
            else
                thisnum(k) = NaN;
            end
        end
        
    end


    
    tempnum = strfind(characters, upper(thischar));



end
