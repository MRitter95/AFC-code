%Modified Feb 25 2016
%
% convert integer knob reading to the alpha-numeric knob reading...
%
% how do we deal with issues of 'wrap around'?
% if value is <0,or >28, how do we deal with it?  
%we deal with it by adding additional characters, 3++ means 3+2*29
% S- = -1
%BUT... 
%
% so now, the output for ItoA will be an array ONLY if all values or
% between 0 and 28
%
%useage:    [thischarArray,  thischarCell]= ItoA(thisnum, settocell)
%
%settocell is optional, by giving a value of 1 will mean that both outputs
%will be cells
%


function [thischarArray,  thischarCell]= ItoA(thisnum, settocell)


    characters = '0123456789ABCDEFGHIJKLMNOPQRS';
    dabase = length(characters);
    thischarArray = char(zeros(1,length(thisnum)));
    % it will output an array correctly only if the value of each element
    % is between the closed interval [0, 28]
    for k = 1:length(thisnum)
        if (thisnum(k)<length(characters) && thisnum(k)>=0)
            thischarArray(k) = characters(thisnum(k)+1);
        else
            thischarArray = NaN;
            break;
        end
    end
    
    thischarCell = {};
    
    for k = 1:length(thisnum)
        currval = thisnum(k);
        thischarCell{k} =  characters(mod(currval, dabase)+1);
        if (currval<0)
            dasymbol = '-';
            numsymbols = fix(-currval/dabase) +1;
        else
            dasymbol = '+'; 
            numsymbols = fix(currval/dabase);
        end
        
        for s = 1:numsymbols
            thischarCell{k} = [thischarCell{k}, dasymbol];
        end
    end

    
    if exist('settocell')
        if settocell
            thischarArray = thischarCell;            
        end
    end
    
end
