


function f_MovePiezo(currentArm, desiredPos)

    currentArm.SetPosOutput(0, desiredPos);
    tmp = 0;
    currentpos = NaN;
    ctr = 0;
    while (1)
        [tmp,currentpos] = (currentArm.GetPosOutput(0,0));
        if (norm(currentpos-desiredPos)<0.05)
            ctr = ctr + 1;
            if (ctr> 3) %let it stabilize
                break;
            end
        end
    end            

end