%useage [data] =  RunOrtec(vi, nreads, whichparams)%#ok
%
% Revised Feb 24 2016
%
%vi: the invoked vi that we want to run
%nreads: the number of reads to perform before quitting
%whichparams do we actually want, in the form of a cell of strings... 
%eg: {'Ortec Starts', 'Ortec Estimated Stops', 'Coincidence ROI'} etc. 
%
% returns the time-averaged data asked for in 'whichparams'

function  [data] = RunOrtec(vi, nreads, whichparams)%#ok


    tmpdata = vi.GetControlValue('Data Out');
    
    indices = [];
    
    for k = 1:length(whichparams)    
        for l = 1:length(tmpdata{1})
            if strcmp(tmpdata{1}{l}, whichparams{k})
                indices = [indices,l];
                break;
            end
        end
    end


    data = [];
    
    for k = 1:nreads
%         tic
        try
            vi.Abort
        end
        vi.Run;
%         toc
        tmpdata = vi.GetControlValue('Data Out');
        data = [data; tmpdata{2}(indices)];
%         pause(0.1);
    end
    
    if (nreads > 1) %only average if we are doing more than 1 read... 
        data = mean(data);
    end

end