%errorfunc.m Revised: Sep 11 2015
%f = cost function
%paramsOpt = is the optimal parameters which minimize the cost function
%when f increases by deltacost, how do the parameters fluctuate (deltaparams)?
%
function [deltaparams ] = errorfunc(  f, paramsOpt, deltacost )%#ok
    
    f_opt = f(paramsOpt);
    
    numparams = length(paramsOpt);
    
    deltaparams = zeros(numparams,1); %a column vector
    
    for k = 1:numparams
        unitvector = zeros(numparams,1);
        unitvector(k) = 1;
        %solve for the deviation when chi-square increases by an amount of deltacost
        deltaparams(k) = abs(fzero(@(x) f_opt + deltacost- f(paramsOpt + x*unitvector), 0 ));
    end

end
