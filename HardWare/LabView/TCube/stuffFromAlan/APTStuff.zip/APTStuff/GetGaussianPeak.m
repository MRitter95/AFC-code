% modified Feb 10, 2016
% useage: [GaussPeak, errpeak,sigma, LSval, peakamp] =
%                       GetGaussianPeak(xdata, ydata, figaxhandle, color scalingfactor)
%
%
%xdata (ydata) - row or col vector of the independent (dependent) data, 
%
% can also plot the fit on top of the data, if you give it figaxhandle, and
% the color of the trace... 


function [GaussPeak, errpeak,sigma, LSval, peakamp, func_optimal] = GetGaussianPeak(xdata, ydata, figaxhandle, color, scalingfactor)%#ok
    
    dafunc = @(params,x) params(1)*exp(-(x-params(2)).^2/params(3).^2) + params(4);
    
    [ymax, maxind]= max(ydata); %#ok
    
    paramsTrial(1) = ymax;
    paramsTrial(2) = xdata(maxind);
    paramsTrial(3) = 2;
    paramsTrial(4) = 0;
    
    errfunc  = @(params) sum(((dafunc(params,xdata)-ydata).^2)./(ydata+1));
    
    paramsOpt = fminsearch(@(params) errfunc(params), paramsTrial, optimset('MaxFunEvals', 5e9));
    
    GaussPeak = paramsOpt(2);
    sigma     = paramsOpt(3);
    LSval     = errfunc(paramsOpt);    
    peakamp  = paramsOpt(1)+paramsOpt(4); %peak amplitude of the Gaussian%

    if length(xdata)>length(paramsTrial) %only run this when there are enough data points
        costfunc = @(params) errfunc(params)*(length(ydata(:))-length(paramsOpt))/errfunc(paramsOpt);
        deltacost = 1; %if cost func goes up/down by this much, how do the params change?
        deltaparams = errorfunc(  @(params) costfunc(params), paramsOpt', deltacost ); 

        errpeak = deltaparams(2);
    else
        errpeak = NaN;
    end
    
    if (exist('figaxhandle','var'))
        xth = linspace(min(xdata), max(xdata), 101);
        yth = dafunc(paramsOpt,xth);
        if (exist('scalingfactor', 'var')) yth = yth*scalingfactor; end
        hold(figaxhandle, 'on');
        
            plot(figaxhandle, xth, yth, color);
        hold(figaxhandle, 'off');
    end
    
    func_optimal = @(x) dafunc(paramsOpt,x);
    
end